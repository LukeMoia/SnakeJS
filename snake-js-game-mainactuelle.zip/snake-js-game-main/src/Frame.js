/*import {SizeWishX} from './main.js';
import {SizeWishY} from './main.js';*/

// export {SizeWishX as nb1,SizeWishY as nb2} from './main.js';