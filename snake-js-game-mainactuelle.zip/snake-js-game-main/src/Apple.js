export class Apple {
  constructor(X, Y, Color) {
    this.X = X;
    this.Y = Y;
    this.Color = Color;
  }
  X = Number;
  Y = Number;
  Color = String;
}