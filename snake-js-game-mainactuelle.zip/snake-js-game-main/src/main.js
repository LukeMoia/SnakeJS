/*import '../css/style.css';

const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');
let valx = 0;
let valy = 0;
let direc = KeyboardEvent.key;

const move = () => {

  // Dessine la grille de jeu
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, 800, 800);
  document.onkeydown = (e) => {
    direc = e.key;
  };
      if(direc == 'ArrowDown'){
        valy += 40;
      }
      else if(direc== 'ArrowUp'){
        valy -= 40;
      }
      else if(direc == 'ArrowRight'){
        valx += 40;
      }
      else if(direc == 'ArrowLeft'){
        valx -= 40;
      }
  ctx.fillStyle = 'white';
  ctx.fillRect(valx, valy, 40, 40);

  // Rafraichit à chaque seconde
  setTimeout(() => {
    requestAnimationFrame(move);
  }, 1000);
};
requestAnimationFrame(move);*/

import '../css/style.css';
import { Snake } from './Snake.js';
import { Apple } from './Apple.js';

const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

/*class Snake {
  constructor(X, Y, Color) {
    this.X = X;
    this.Y = Y;
    this.Color = Color;
  }
  X = Number;
  Y = Number;
  NbPartCorps = 0;
  Tabint = [];
  Color = String;
  Direc = '';
}

class Apple {
  constructor(X, Y, Color) {
    this.X = X;
    this.Y = Y;
    this.Color = Color;
  }
  X = Number;
  Y = Number;
  Color = String;
}*/
 ////////////////////////////////////////////////// commenter le code
const Randoms = (num, size) => {
  let val = Math.random() * num;
  return (val - (val % size));
}

// pour changer la taille du jeux et le nombre de cases (X = Longueur / Y = Hauteur)
const SizeBordX = 800
const SizeBordY = 800
const NBCasesX = 20;
const NBCasesY = 20;

let NBCaseX = NBCasesX;
let NBCaseY = NBCasesY;

for (; SizeBordX / NBCaseX != Math.floor(SizeBordX / NBCaseX);) {
  NBCaseX++;
}

for (; SizeBordY / NBCaseY != Math.floor(SizeBordY / NBCaseY);) {
  NBCaseY++;
}
/*
Pas directement modifiable. Le programme est prévue pour du 800 sur 800
for(;SizeBordX / NBCasesX != Math.floor(SizeBordX / NBCasesX);){
SizeBordX++;
}

for(;SizeBordY / NBCasesY != Math.floor(SizeBordY / NBCasesY);){
  SizeBordY++;
}*/



let snake = new Snake(Randoms(SizeBordX + 1, SizeBordX / NBCaseX), Randoms(SizeBordY + 1, SizeBordY / NBCaseY), 'Green');
let apple = new Apple(Randoms(SizeBordX + 1, SizeBordX / NBCaseX), Randoms(SizeBordY + 1, SizeBordY / NBCaseY), 'Red');
let lose = false;
const move = () => {

  snake.Tabint.push(snake.X);
  snake.Tabint.push(snake.Y);

  // Dessine la grille de jeu
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, SizeBordX, SizeBordY);
  document.onkeydown = (e) => {
    if (e.key == 'ArrowDown' && snake.Direc != 'ArrowUp') {
      snake.Direc = e.key;
    }
    else if (e.key == 'ArrowUp' && snake.Direc != 'ArrowDown') {
      snake.Direc = e.key;
    }
    else if (e.key == 'ArrowRight' && snake.Direc != 'ArrowLeft') {
      snake.Direc = e.key;
    }
    else if (e.key == 'ArrowLeft' && snake.Direc != 'ArrowRight') {
      snake.Direc = e.key;
    }
  };
  if (snake.Direc == 'ArrowDown') {
    if (snake.Y < SizeBordY - (SizeBordY / NBCaseY)) {
      snake.Y += SizeBordY / NBCaseY;
    }
    else {
      lose = true;
    }
  }
  else if (snake.Direc == 'ArrowUp') {
    if (snake.Y > 0) {
      snake.Y -= SizeBordY / NBCaseY;
    }
    else {
      lose = true;
    }
  }
  else if (snake.Direc == 'ArrowRight') {
    if (snake.X < SizeBordX - (SizeBordX / NBCaseX)) {
      snake.X += SizeBordX / NBCaseX;
    }
    else {
      lose = true;
    }
  }
  else if (snake.Direc == 'ArrowLeft') {
    if (snake.X > 0) {
      snake.X -= SizeBordX / NBCaseX;
    }
    else {
      lose = true;
    }
  }

  if (apple.X == snake.X && apple.Y == snake.Y) {
    snake.NbPartCorps++;
    for (let z = 0; z < snake.NbPartCorps * 2 + 1; z += 2) {
      for (; apple.X == snake.X && apple.Y == snake.Y;) {
        apple.X = Randoms(SizeBordX + 1, SizeBordX / NBCaseX);
        apple.Y = Randoms(SizeBordY + 1, SizeBordY / NBCaseY);
      }
      if (apple.X == snake.Tabint[snake.Tabint.length - z] && apple.Y == snake.Tabint[snake.Tabint.length + 1 - z]) {
        apple.X = Randoms(SizeBordX + 1, SizeBordX / NBCaseX);
        apple.Y = Randoms(SizeBordY + 1, SizeBordY / NBCaseY);
      }
    }
    /*for (; apple.X == snake.X && apple.Y == snake.Y;) {
      apple.X = Randoms(SizeBordX + 1, SizeBordX / NBCasesX);
      apple.Y = Randoms(SizeBordY + 1, SizeBordY / NBCasesY);
    }*/
  }
  ctx.fillStyle = apple.Color;
  ctx.fillRect(apple.X, apple.Y, SizeBordX / NBCaseX, SizeBordY / NBCaseY);

  ctx.fillStyle = snake.Color;
  ctx.fillRect(snake.X, snake.Y, SizeBordX / NBCaseX, SizeBordY / NBCaseY);

  for (let z = 0; z < snake.NbPartCorps * 2 + 1; z += 2) {
    ctx.fillStyle = snake.Color;
    ctx.fillRect(snake.Tabint[snake.Tabint.length - z], snake.Tabint[snake.Tabint.length + 1 - z], SizeBordX / NBCaseX, SizeBordY / NBCaseY);
    if (snake.Tabint[snake.Tabint.length - z] == snake.X && snake.Tabint[snake.Tabint.length + 1 - z] == snake.Y) {
      lose = true;
    }
  }


  ctx.fillStyle = 'White';
  ctx.font = '20px serif';
  ctx.fillText(snake.NbPartCorps, 30, 50);

  if (lose == false) {
    // Rafraichit à chaque seconde
    setTimeout(() => {
      requestAnimationFrame(move);
    }, 100);
  }
  else {
    ctx.fillStyle = 'Black';
    ctx.fillRect(30, 30, 40, 40);

    ctx.fillStyle = 'White';
    ctx.font = '30px serif';
    ctx.fillText('Vous avez perdu et votre score est : ' + snake.NbPartCorps, 40, 90);
  }
};
requestAnimationFrame(move);