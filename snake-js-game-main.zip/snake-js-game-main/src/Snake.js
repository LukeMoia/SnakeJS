export class Snake {
  constructor(X, Y, Color) {
    this.X = X;
    this.Y = Y;
    this.Color = Color;
  }
  X = Number;
  Y = Number;
  NbPartCorps = 0;
  Tabint = [];
  Color = String;
  Direc = '';
}